// Enviar los datos del formulario mediante AJAX
jQuery('#formulario-bluecell').submit(function(e) {
    e.preventDefault();
    
    var formData = jQuery(this).serialize();
    
    jQuery.ajax({
        type: 'POST',
        url: ajaxurl,
        data: formData + '&action=formulario_bluecell_save_data',
        success: function(response) {
        },
        error: function(xhr, status, error) {
            console.log(error);
        }
    });
});