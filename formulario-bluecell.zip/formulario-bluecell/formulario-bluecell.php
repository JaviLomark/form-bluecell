<?php
/*
Plugin Name: Formulario Bluecell
Description: Plugin para insertar un formulario y guardar los datos en la base de datos.
Version: 1.0.0
Author: Javi Lomark
Author URI: https://javilomark.com
*/

// Acción para insertar el formulario en single.php
function formulario_bluecell_insert_form($content) {
    if (is_single()) {
        $form = '<form id="formulario-bluecell" action="" method="post">
            <label for="nombre">Nombre:</label>
            <input type="text" name="nombre" required><br>
            
            <label for="email">Email:</label>
            <input type="email" name="email" required><br>
            
            <label for="telefono">Teléfono:</label>
            <input type="text" name="telefono" required><br>
            
            <label for="mensaje">Mensaje:</label>
            <textarea name="mensaje" required></textarea><br>
            
            <label for="asunto">Asunto:</label>
            <input type="text" name="asunto" required><br>
            
            <input type="checkbox" name="politicas" required>
            <label for="politicas">Acepto las políticas</label><br>
            
            <input type="submit" value="Enviar">
        </form>';

        $content .= $form;
    }

    return $content;
}
add_filter('the_content', 'formulario_bluecell_insert_form');

// Acción para crear la tabla en la base de datos al activar el plugin
function formulario_bluecell_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'formulario_bluecell';
    
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        telefono VARCHAR(20) NOT NULL,
        mensaje VARCHAR(255) NOT NULL,
        asunto VARCHAR(100) NOT NULL,
        fecha DATETIME NOT NULL
) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
dbDelta($sql);

}
register_activation_hook(__FILE__, 'formulario_bluecell_create_table');

// Acción para guardar los datos del formulario en la base de datos
function formulario_bluecell_save_data() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nombre'])) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'formulario_bluecell';
        
        $nombre = sanitize_text_field($_POST['nombre']);
        $email = sanitize_email($_POST['email']);
        $telefono = sanitize_text_field($_POST['telefono']);
        $mensaje = sanitize_textarea_field($_POST['mensaje']);
        $asunto = sanitize_text_field($_POST['asunto']);
        $fecha = current_time('mysql');
        
        $data = array(
            'nombre' => $nombre,
            'email' => $email,
            'telefono' => $telefono,
            'mensaje' => $mensaje,
            'asunto' => $asunto,
            'fecha' => $fecha
        );
        
        $wpdb->insert($table_name, $data);
    }
}
add_action('wp_ajax_formulario_bluecell_save_data', 'formulario_bluecell_save_data');
add_action('wp_ajax_nopriv_formulario_bluecell_save_data', 'formulario_bluecell_save_data');


// Acción para eliminar la tabla de la base de datos al desactivar el plugin
function formulario_bluecell_delete_table() {
global $wpdb;
$table_name = $wpdb->prefix . 'formulario_bluecell';
$wpdb->query("DROP TABLE IF EXISTS $table_name");
}
register_deactivation_hook(__FILE__, 'formulario_bluecell_delete_table');

// Acción para agregar una página en el CMS para mostrar los datos del formulario
function formulario_bluecell_menu_page() {
add_menu_page(
'Formulario Bluecell',
'Formulario Bluecell',
'manage_options',
'formulario-bluecell',
'formulario_bluecell_display_data'
);
}
add_action('admin_menu', 'formulario_bluecell_menu_page');

// Función para cargar los scripts y estilos de DataTables
function formulario_bluecell_enqueue_scripts() {
    wp_enqueue_script('jquery');
    wp_enqueue_script('datatables', 'https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js', array('jquery'), '1.13.4', true);
    wp_enqueue_script('datatables-buttons', 'https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js', array('jquery'), '2.3.6', true);
    wp_enqueue_script('datatables-jszip', 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js', array('jquery'), '3.1.3', true);
    wp_enqueue_script('datatables-pdfmake', 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js', array('jquery'), '0.1.53', true);
    wp_enqueue_script('datatables-vfs-fonts', 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js', array('jquery'), '0.1.53', true);
    wp_enqueue_script('datatables-buttons-html5', 'https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js', array('jquery'), '2.3.6', true);
    
    wp_enqueue_style('datatables-css', 'https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css');
    wp_enqueue_style('datatables-buttons-css', 'https://cdn.datatables.net/buttons/2.3.6/css/buttons.dataTables.min.css');

    // Enqueue el archivo JavaScript personalizado
    wp_enqueue_script('formulario-bluecell-js', plugins_url('js/formulario-bluecell.js', __FILE__), array('jquery'), '1.0.0', true);
}

// Función para mostrar los datos del formulario en la página del CMS
function formulario_bluecell_display_data() {
global $wpdb;
$table_name = $wpdb->prefix . 'formulario_bluecell';
$data = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

echo '<h1>Registros del Formulario Bluecell</h1>';
echo '<table id="formulario-bluecell-table" class="display" style="width:100%">';
echo '<thead><tr><th>ID</th><th>Nombre</th><th>Email</th><th>Teléfono</th><th>Mensaje</th><th>Asunto</th><th>Fecha</th></tr></thead>';
echo '<tbody>';

foreach ($data as $row) {
    echo '<tr>';
    echo '<td>' . $row['id'] . '</td>';
    echo '<td>' . $row['nombre'] . '</td>';
    echo '<td>' . $row['email'] . '</td>';
    echo '<td>' . $row['telefono'] . '</td>';
    echo '<td>' . $row['mensaje'] . '</td>';
    echo '<td>' . $row['asunto'] . '</td>';
    echo '<td>' . $row['fecha'] . '</td>';
    echo '</tr>';
}
echo '</tbody>';
echo '</table>';

// Código para inicializar DataTables
echo '
<script>
    jQuery(document).ready(function() {
        jQuery("#formulario-bluecell-table").DataTable({
            dom: "Bfrtip",
            buttons: [
                "copyHtml5",
                "excelHtml5",
                "csvHtml5",
                "pdfHtml5"
            ]
        });
    });
</script>';
}

// Hook para cargar los scripts y estilos de DataTables
add_action('admin_enqueue_scripts', 'formulario_bluecell_enqueue_scripts');
?>
